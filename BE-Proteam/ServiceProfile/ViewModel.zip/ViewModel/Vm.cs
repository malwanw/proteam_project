﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceProfile.ViewModel
{
    public class Vm
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Npp { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public DateTime? ActiveDate { get; set; }
        public DateTime? LastWorkDate { get; set; }
        public decimal? TotalManhour { get; set; }
        public decimal? Cost { get; set; }
        public int? ResourceType { get; set; }
        public string tipe_resource { get; set; }
        public int? JenjabId { get; set; }
        public string JenjangJabatan { get; set; }
        public int? KelompokId { get; set; }
        public string Kelompok { get; set; }
        public int? Role { get; set; }
        public string nama_role { get; set; }
        public string ProjectExp { get; set; }
        public int? Status { get; set; }
        public string nama_status { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedTime { get; set; }
        public DateTime? UpdateTime { get; set; }


        public string Skill { get; set; }

    }
    public class SkillName
    {
        public string Skillset { get; set; }
    }

    public class ContohData
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class VendorMandays
    {
        public int Mandays_id { get; set; }
        public string VendorName { get; set; }

        public int TotalMandays { get; set; }
    }

    public class DashboardVendor
    {
        public int TotalVendor { get; set; }

        public int TotalMandays { get; set; }
        public List<VendorMandays> ListVendors { get; set; }
    }

    public class ResourceKelompok
    {
        public int Kelompok_id { get; set; }
        public string Kelompok { get; set; }

        public int TotalResourceKelompok { get; set; }
    }

    public class ResourceRole
    {
        public int Role { get; set; }
        public string Name { get; set; }

        public int TotalResourceRole { get; set; }
    }

    public class ResourceType
    {
        public int ResourceTypeVal { get; set; }
        public string Name { get; set; }

        public int TotalResourceType { get; set; }
        public string PercentageRecourceType { get; set; }
    }


    public class DashboardResources
    {
        public int TotalResource { get; set; }

        public List<ResourceKelompok> ListResourceKelompok { get; set; }

        public List<ResourceRole> ListResourceRole { get; set; }

        public List<ResourceType> ListResourceType { get; set; }
    }

    public class MandaysStatus
    {
        public int MandaysId { get; set; }
        public string VendorName { get; set; }
        public string ContractNumber { get; set; }
        public DateTime? StartContract { get; set; }
        public DateTime? LastContract { get; set; }
        public int TotalMandays { get; set; }
        public int UsageMandays { get; set; }
        public int AvailableMandays { get; set; }
        public int Status { get; set; }
        public string nama_status { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedTime { get; set; }
        public DateTime? UpdateTime { get; set; }
        public string Notes { get; set; }
    }

    public class Member
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Npp { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public DateTime? ActiveDate { get; set; }
        public DateTime? LastWorkDate { get; set; }
        public decimal? TotalManhour { get; set; }
        public decimal? Cost { get; set; }
        public int? ResourceType { get; set; }
        public string tipe_resource { get; set; }
        public int? JenjabId { get; set; }
        public string JenjangJabatan { get; set; }
        public int? KelompokId { get; set; }
        public string Kelompok { get; set; }
        public int? Role { get; set; }
        public string nama_role { get; set; }
        public string ProjectExp { get; set; }
        public int? Status { get; set; }
        public string nama_status { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedTime { get; set; }
        public DateTime? UpdateTime { get; set; }
    }


    public class KelompokProfile
    {
        public int KelompokId { get; set; }
        public string KelompokName { get; set; }
        public int? TotalEmployee { get; set; }
        public decimal? TotalManhour { get; set; }
        public int Status { get; set; }
        public string nama_status { get; set; }
        public List<Member> ListMember { get; set; }
        public string Skillset { get; set; }

    }

    public class UnitProfile
    {
        public int Unit_id { get; set; }
        public int? Kelompok_id { get; set; }
        public string KelompokName { get; set; }
        public int? TotalEmployee { get; set; }
        public decimal? TotalManhour { get; set; }
        public string Skill { get; set; }
        public int? Status { get; set; }
        public string StatusName { get; set; }
        public DateTime? CreatedTime { get; set; }
        public DateTime? UpdatedTime { get; set; }
        public List<Member> ListMember { get; set; }

    }

    public class PostRE
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Npp { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public DateTime? ActiveDate { get; set; }
        public DateTime? LastWorkDate { get; set; }
        public decimal? TotalManhour { get; set; }
        public int? ResourceType { get; set; }
        public int? JenjabId { get; set; }
        public int? KelompokId { get; set; }
        public int? Role { get; set; }
        public string ProjectExp { get; set; }
        public int? Status { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedTime { get; set; }
        public DateTime? UpdateTime { get; set; }
        public List<ListSkillEmp> ListSkill { get; set; }

    }
    public class ListSkillEmp
    {
        public int? SkillId { get; set; }
    }
}

   