﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ServiceProfile.Models
{
    public partial class User
    {
        //public int Id { get; set; }
        public string UserName { get; set; }
        public string UserNpp { get; set; }

        public string Token { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public int? Status { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedTime { get; set; }
        public DateTime? UpdateTime { get; set; }
    }
}
